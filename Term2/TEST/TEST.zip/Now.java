package Term2.TEST;

public interface Now {
    abstract void now(int yearsnow);
}
