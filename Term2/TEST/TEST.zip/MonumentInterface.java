package Term2.TEST;

public interface MonumentInterface {
    abstract String Classname();
}
